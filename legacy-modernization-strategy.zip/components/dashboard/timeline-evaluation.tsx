"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"
import { changeRequests as initialChangeRequests, timelineMetrics, legacySystems } from "@/lib/mock-data"
import type { ChangeRequest } from "@/lib/types"
import {
  Clock,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Timer,
  Calendar,
  ArrowUpRight,
  Pause,
  Play,
  Plus,
  Send,
  MessageSquare,
  BarChart3,
  X
} from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"

const statusConfig = {
  pending: { icon: Clock, color: "text-muted-foreground", bg: "bg-muted" },
  "in-progress": { icon: Play, color: "text-chart-2", bg: "bg-chart-2/20" },
  completed: { icon: CheckCircle2, color: "text-chart-1", bg: "bg-chart-1/20" },
  blocked: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/20" }
}

const priorityConfig = {
  critical: { color: "bg-destructive text-destructive-foreground" },
  high: { color: "bg-chart-3 text-foreground" },
  medium: { color: "bg-chart-2 text-foreground" },
  low: { color: "bg-chart-1 text-primary-foreground" }
}

export function TimelineEvaluation() {
  const [changeRequestsList, setChangeRequestsList] = useState<ChangeRequest[]>(initialChangeRequests)
  const [selectedRequest, setSelectedRequest] = useState<ChangeRequest | null>(null)
  const [viewMode, setViewMode] = useState<"list" | "timeline">("list")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [newEstimate, setNewEstimate] = useState("")
  const [communicationNote, setCommunicationNote] = useState("")
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [newRequestDialogOpen, setNewRequestDialogOpen] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  // New request form state
  const [newRequest, setNewRequest] = useState({
    title: "",
    description: "",
    systemId: "",
    estimatedDays: "",
    priority: "medium" as ChangeRequest["priority"],
    legacyImpact: "medium" as ChangeRequest["legacyImpact"]
  })

  const showToast = useCallback((message: string) => {
    setToastMessage(message)
    setTimeout(() => setToastMessage(null), 3000)
  }, [])

  const filteredRequests = changeRequestsList.filter(
    r => statusFilter === "all" || r.status === statusFilter
  )

  const stats = {
    total: changeRequestsList.length,
    completed: changeRequestsList.filter(r => r.status === 'completed').length,
    inProgress: changeRequestsList.filter(r => r.status === 'in-progress').length,
    blocked: changeRequestsList.filter(r => r.status === 'blocked').length,
    pending: changeRequestsList.filter(r => r.status === 'pending').length,
    avgOverrun: Math.round(
      changeRequestsList
        .filter(r => r.actualDays && r.actualDays > r.estimatedDays)
        .reduce((acc, r) => acc + ((r.actualDays! - r.estimatedDays) / r.estimatedDays * 100), 0) /
      (changeRequestsList.filter(r => r.actualDays).length || 1)
    )
  }

  const deliveryAccuracy = timelineMetrics.map(m => ({
    ...m,
    accuracy: Math.round((m.actual / m.planned) * 100),
    blockedRate: Math.round((m.blocked / m.planned) * 100)
  }))

  const getTimelinePosition = (request: ChangeRequest) => {
    const totalDays = 90
    const startOffset = Math.floor(Math.random() * 30)
    const width = (request.estimatedDays / totalDays) * 100
    return { left: `${(startOffset / totalDays) * 100}%`, width: `${Math.min(width, 40)}%` }
  }

  const handleUpdateEstimate = () => {
    if (!selectedRequest || !newEstimate) return
    
    setChangeRequestsList(prev => prev.map(r => 
      r.id === selectedRequest.id 
        ? { ...r, estimatedDays: parseInt(newEstimate) }
        : r
    ))
    setSelectedRequest(prev => prev ? { ...prev, estimatedDays: parseInt(newEstimate) } : null)
    setNewEstimate("")
    showToast(`Timeline updated to ${newEstimate} days`)
  }

  const handleSendCommunication = () => {
    if (!communicationNote.trim()) return
    setCommunicationNote("")
    showToast("Stakeholder notification sent successfully")
  }

  const handleStatusChange = (requestId: string, newStatus: ChangeRequest["status"]) => {
    setChangeRequestsList(prev => prev.map(r => 
      r.id === requestId ? { ...r, status: newStatus } : r
    ))
    if (selectedRequest?.id === requestId) {
      setSelectedRequest(prev => prev ? { ...prev, status: newStatus } : null)
    }
    showToast(`Request status updated to ${newStatus}`)
  }

  const handleAddBlocker = (requestId: string, blocker: string) => {
    if (!blocker.trim()) return
    setChangeRequestsList(prev => prev.map(r => 
      r.id === requestId ? { ...r, blockers: [...r.blockers, blocker] } : r
    ))
    showToast("Blocker added")
  }

  const handleRemoveBlocker = (requestId: string, index: number) => {
    setChangeRequestsList(prev => prev.map(r => 
      r.id === requestId ? { ...r, blockers: r.blockers.filter((_, i) => i !== index) } : r
    ))
    showToast("Blocker removed")
  }

  const handleCreateRequest = () => {
    if (!newRequest.title || !newRequest.systemId || !newRequest.estimatedDays) {
      showToast("Please fill in all required fields")
      return
    }

    const system = legacySystems.find(s => s.id === newRequest.systemId)
    const newReq: ChangeRequest = {
      id: `cr-${Date.now()}`,
      title: newRequest.title,
      description: newRequest.description,
      systemId: newRequest.systemId,
      systemName: system?.name || "Unknown System",
      requestedDate: new Date().toISOString().split('T')[0],
      estimatedDays: parseInt(newRequest.estimatedDays),
      status: "pending",
      blockers: [],
      legacyImpact: newRequest.legacyImpact,
      priority: newRequest.priority
    }

    setChangeRequestsList(prev => [newReq, ...prev])
    setNewRequest({
      title: "",
      description: "",
      systemId: "",
      estimatedDays: "",
      priority: "medium",
      legacyImpact: "medium"
    })
    setNewRequestDialogOpen(false)
    showToast("New change request created successfully")
  }

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-2 fade-in duration-300">
          <div className="bg-primary text-primary-foreground px-4 py-3 rounded-lg shadow-lg flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Timeline Evaluation</h2>
          <p className="text-sm text-muted-foreground">
            Evaluate and communicate realistic delivery timelines for legacy system changes
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "list" | "timeline")}>
            <TabsList className="bg-secondary">
              <TabsTrigger value="list" className="text-xs">List View</TabsTrigger>
              <TabsTrigger value="timeline" className="text-xs">Timeline</TabsTrigger>
            </TabsList>
          </Tabs>
          <Dialog open={newRequestDialogOpen} onOpenChange={setNewRequestDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Request
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card">
              <DialogHeader>
                <DialogTitle>New Change Request</DialogTitle>
                <DialogDescription>
                  Submit a new change request with timeline estimation
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input 
                    id="title" 
                    placeholder="Enter request title" 
                    className="bg-secondary"
                    value={newRequest.title}
                    onChange={(e) => setNewRequest(prev => ({ ...prev, title: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea 
                    id="description" 
                    placeholder="Describe the change..." 
                    className="bg-secondary"
                    value={newRequest.description}
                    onChange={(e) => setNewRequest(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Target System *</Label>
                    <Select 
                      value={newRequest.systemId} 
                      onValueChange={(v) => setNewRequest(prev => ({ ...prev, systemId: v }))}
                    >
                      <SelectTrigger className="bg-secondary">
                        <SelectValue placeholder="Select system" />
                      </SelectTrigger>
                      <SelectContent>
                        {legacySystems.map(system => (
                          <SelectItem key={system.id} value={system.id}>
                            {system.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="estimate">Estimated Days *</Label>
                    <Input 
                      id="estimate" 
                      type="number" 
                      placeholder="Days" 
                      className="bg-secondary"
                      value={newRequest.estimatedDays}
                      onChange={(e) => setNewRequest(prev => ({ ...prev, estimatedDays: e.target.value }))}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Priority</Label>
                    <Select 
                      value={newRequest.priority} 
                      onValueChange={(v) => setNewRequest(prev => ({ ...prev, priority: v as ChangeRequest["priority"] }))}
                    >
                      <SelectTrigger className="bg-secondary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Legacy Impact</Label>
                    <Select 
                      value={newRequest.legacyImpact} 
                      onValueChange={(v) => setNewRequest(prev => ({ ...prev, legacyImpact: v as ChangeRequest["legacyImpact"] }))}
                    >
                      <SelectTrigger className="bg-secondary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setNewRequestDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleCreateRequest}>Submit Request</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Delivery Rate</p>
                <p className="text-2xl font-bold text-foreground">
                  {stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0}%
                </p>
              </div>
              <div className="rounded-lg bg-chart-1/20 p-2">
                <CheckCircle2 className="h-5 w-5 text-chart-1" />
              </div>
            </div>
            <Progress value={stats.total > 0 ? (stats.completed / stats.total) * 100 : 0} className="mt-3 h-1.5" />
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Blocked Requests</p>
                <p className="text-2xl font-bold text-foreground">{stats.blocked}</p>
              </div>
              <div className="rounded-lg bg-destructive/20 p-2">
                <Pause className="h-5 w-5 text-destructive" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {stats.total > 0 ? Math.round((stats.blocked / stats.total) * 100) : 0}% of total requests
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Timeline Overrun</p>
                <p className="text-2xl font-bold text-foreground">+{stats.avgOverrun}%</p>
              </div>
              <div className="rounded-lg bg-chart-3/20 p-2">
                <Timer className="h-5 w-5 text-chart-3" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Legacy constraints add delays
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Progress</p>
                <p className="text-2xl font-bold text-foreground">{stats.inProgress}</p>
              </div>
              <div className="rounded-lg bg-chart-2/20 p-2">
                <Play className="h-5 w-5 text-chart-2" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {stats.pending} pending requests
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Delivery Accuracy Chart */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base font-medium">
            <BarChart3 className="h-4 w-4 text-chart-2" />
            Delivery Performance Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={deliveryAccuracy}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--popover)',
                    border: '1px solid var(--border)',
                    borderRadius: '8px',
                    color: 'var(--popover-foreground)'
                  }}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="planned"
                  stackId="1"
                  stroke="var(--chart-2)"
                  fill="var(--chart-2)"
                  fillOpacity={0.3}
                  name="Planned"
                />
                <Area
                  type="monotone"
                  dataKey="actual"
                  stackId="2"
                  stroke="var(--chart-1)"
                  fill="var(--chart-1)"
                  fillOpacity={0.5}
                  name="Delivered"
                />
                <Area
                  type="monotone"
                  dataKey="blocked"
                  stackId="3"
                  stroke="var(--destructive)"
                  fill="var(--destructive)"
                  fillOpacity={0.3}
                  name="Blocked"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Status Filter Tabs */}
      <Tabs value={statusFilter} onValueChange={setStatusFilter}>
        <TabsList className="bg-secondary">
          <TabsTrigger value="all" className="text-xs">
            All ({changeRequestsList.length})
          </TabsTrigger>
          <TabsTrigger value="pending" className="text-xs">
            Pending ({stats.pending})
          </TabsTrigger>
          <TabsTrigger value="in-progress" className="text-xs">
            In Progress ({stats.inProgress})
          </TabsTrigger>
          <TabsTrigger value="blocked" className="text-xs">
            Blocked ({stats.blocked})
          </TabsTrigger>
          <TabsTrigger value="completed" className="text-xs">
            Completed ({stats.completed})
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Change Requests List */}
      {viewMode === "list" ? (
        <Card className="bg-card border-border">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">Request</TableHead>
                <TableHead className="text-muted-foreground">System</TableHead>
                <TableHead className="text-muted-foreground">Status</TableHead>
                <TableHead className="text-muted-foreground">Priority</TableHead>
                <TableHead className="text-muted-foreground">Timeline</TableHead>
                <TableHead className="text-muted-foreground">Legacy Impact</TableHead>
                <TableHead className="text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRequests.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    No requests found for this filter
                  </TableCell>
                </TableRow>
              ) : (
                filteredRequests.map((request) => {
                  const StatusIcon = statusConfig[request.status].icon
                  return (
                    <TableRow key={request.id} className="border-border">
                      <TableCell>
                        <div className="space-y-1">
                          <p className="font-medium text-foreground">{request.title}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1">
                            {request.description}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-foreground">
                        {request.systemName}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "gap-1",
                            statusConfig[request.status].color,
                            statusConfig[request.status].bg
                          )}
                        >
                          <StatusIcon className="h-3 w-3" />
                          {request.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={priorityConfig[request.priority].color}>
                          {request.priority}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <p className="text-sm text-foreground">{request.estimatedDays} days</p>
                          {request.actualDays && (
                            <p className={cn(
                              "text-xs",
                              request.actualDays > request.estimatedDays 
                                ? "text-destructive" 
                                : "text-chart-1"
                            )}>
                              Actual: {request.actualDays} days
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline"
                          className={cn(
                            request.legacyImpact === 'high' 
                              ? "text-destructive border-destructive/30" 
                              : request.legacyImpact === 'medium'
                              ? "text-chart-3 border-chart-3/30"
                              : "text-chart-1 border-chart-1/30"
                          )}
                        >
                          {request.legacyImpact} impact
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Dialog open={detailDialogOpen && selectedRequest?.id === request.id} onOpenChange={(open) => {
                          setDetailDialogOpen(open)
                          if (open) setSelectedRequest(request)
                          else setSelectedRequest(null)
                        }}>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => {
                                setSelectedRequest(request)
                                setDetailDialogOpen(true)
                              }}
                            >
                              <ArrowUpRight className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-lg bg-card">
                            <DialogHeader>
                              <DialogTitle>{request.title}</DialogTitle>
                              <DialogDescription>{request.description}</DialogDescription>
                            </DialogHeader>
                            
                            <div className="space-y-4 py-4">
                              {/* Status Change */}
                              <div className="space-y-2">
                                <Label className="text-sm font-medium">Update Status</Label>
                                <div className="flex gap-2 flex-wrap">
                                  {(["pending", "in-progress", "blocked", "completed"] as const).map(status => (
                                    <Button
                                      key={status}
                                      variant={request.status === status ? "default" : "outline"}
                                      size="sm"
                                      className={cn(
                                        "text-xs",
                                        request.status !== status && "bg-transparent"
                                      )}
                                      onClick={() => handleStatusChange(request.id, status)}
                                    >
                                      {status}
                                    </Button>
                                  ))}
                                </div>
                              </div>

                              {/* Blockers */}
                              <div className="space-y-2">
                                <Label className="text-sm font-medium flex items-center gap-2">
                                  <AlertCircle className="h-4 w-4 text-destructive" />
                                  Blockers ({request.blockers.length})
                                </Label>
                                {request.blockers.length > 0 && (
                                  <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-3">
                                    <ul className="space-y-2">
                                      {request.blockers.map((blocker, i) => (
                                        <li key={i} className="text-sm text-muted-foreground flex items-center justify-between">
                                          <span>• {blocker}</span>
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            className="h-6 w-6 p-0"
                                            onClick={() => handleRemoveBlocker(request.id, i)}
                                          >
                                            <X className="h-3 w-3" />
                                          </Button>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                                <div className="flex gap-2">
                                  <Input
                                    placeholder="Add blocker..."
                                    className="bg-secondary"
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        handleAddBlocker(request.id, e.currentTarget.value)
                                        e.currentTarget.value = ''
                                      }
                                    }}
                                  />
                                </div>
                              </div>

                              {/* Timeline Estimate Update */}
                              <div className="space-y-2">
                                <Label className="text-sm font-medium">Update Timeline Estimate</Label>
                                <div className="flex gap-2">
                                  <Input
                                    type="number"
                                    placeholder="New estimate (days)"
                                    value={newEstimate}
                                    onChange={(e) => setNewEstimate(e.target.value)}
                                    className="bg-secondary"
                                  />
                                  <Button variant="outline" size="sm" onClick={handleUpdateEstimate}>
                                    Update
                                  </Button>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  Current: {request.estimatedDays} days | Legacy adds ~{Math.round(request.estimatedDays * 0.3)} days
                                </p>
                              </div>

                              {/* Communication */}
                              <div className="space-y-2">
                                <Label className="text-sm font-medium flex items-center gap-2">
                                  <MessageSquare className="h-4 w-4" />
                                  Stakeholder Communication
                                </Label>
                                <Textarea
                                  placeholder="Add notes for stakeholder update..."
                                  value={communicationNote}
                                  onChange={(e) => setCommunicationNote(e.target.value)}
                                  className="bg-secondary"
                                />
                                <Button className="w-full gap-2" onClick={handleSendCommunication}>
                                  <Send className="h-4 w-4" />
                                  Send Timeline Update
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </Card>
      ) : (
        /* Timeline View */
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">90-Day Timeline View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredRequests.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No requests found for this filter</p>
              ) : (
                filteredRequests.map((request) => {
                  const position = getTimelinePosition(request)
                  const StatusIcon = statusConfig[request.status].icon
                  return (
                    <div key={request.id} className="relative">
                      <div className="flex items-center gap-4">
                        <div className="w-40 shrink-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {request.title}
                          </p>
                          <p className="text-xs text-muted-foreground">{request.systemName}</p>
                        </div>
                        <div className="relative flex-1 h-8 rounded bg-secondary">
                          <div
                            className={cn(
                              "absolute top-1 bottom-1 rounded flex items-center justify-center text-xs font-medium",
                              request.status === 'completed' && "bg-chart-1/30 text-chart-1",
                              request.status === 'in-progress' && "bg-chart-2/30 text-chart-2",
                              request.status === 'blocked' && "bg-destructive/30 text-destructive",
                              request.status === 'pending' && "bg-muted text-muted-foreground"
                            )}
                            style={position}
                          >
                            {request.estimatedDays}d
                          </div>
                        </div>
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "shrink-0 gap-1",
                            statusConfig[request.status].color
                          )}
                        >
                          <StatusIcon className="h-3 w-3" />
                        </Badge>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
