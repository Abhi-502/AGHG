"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { modernizationProjects as initialProjects, complexityTrendData, legacySystems } from "@/lib/mock-data"
import type { ModernizationProject } from "@/lib/types"
import {
  Layers,
  ArrowRight,
  GitBranch,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Play,
  Pause,
  Settings,
  TrendingUp,
  ArrowLeftRight,
  RefreshCw,
  Zap,
  Target
} from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts"

const statusConfig = {
  planning: { icon: Clock, color: "text-muted-foreground", bg: "bg-muted", label: "Planning" },
  migration: { icon: ArrowRight, color: "text-chart-2", bg: "bg-chart-2/20", label: "Migration" },
  parallel: { icon: ArrowLeftRight, color: "text-chart-3", bg: "bg-chart-3/20", label: "Parallel Running" },
  cutover: { icon: Zap, color: "text-primary", bg: "bg-primary/20", label: "Cutover" },
  completed: { icon: CheckCircle2, color: "text-chart-1", bg: "bg-chart-1/20", label: "Completed" }
}

const complexityColors = {
  low: "bg-chart-1 text-primary-foreground",
  medium: "bg-chart-2 text-foreground",
  high: "bg-chart-3 text-foreground",
  critical: "bg-destructive text-destructive-foreground"
}

const riskColors = {
  low: "text-chart-1 border-chart-1/30",
  medium: "text-chart-3 border-chart-3/30",
  high: "text-destructive border-destructive/30"
}

export function ScaleGrowth() {
  const [projects, setProjects] = useState<ModernizationProject[]>(initialProjects)
  const [selectedProject, setSelectedProject] = useState<ModernizationProject | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [notes, setNotes] = useState<Record<string, string>>({})

  const showToast = useCallback((message: string) => {
    setToastMessage(message)
    setTimeout(() => setToastMessage(null), 3000)
  }, [])

  const filteredProjects = projects.filter(
    p => filterStatus === "all" || p.status === filterStatus
  )

  const stats = {
    total: projects.length,
    planning: projects.filter(p => p.status === 'planning').length,
    inProgress: projects.filter(p => ['migration', 'parallel', 'cutover'].includes(p.status)).length,
    completed: projects.filter(p => p.status === 'completed').length,
    parallelRunning: projects.filter(p => p.parallelRunning).length,
    avgProgress: Math.round(projects.reduce((a, p) => a + p.progress, 0) / projects.length),
    highRisk: projects.filter(p => p.riskLevel === 'high').length
  }

  const statusDistribution = [
    { name: 'Planning', value: stats.planning, fill: 'var(--muted-foreground)' },
    { name: 'Migration', value: projects.filter(p => p.status === 'migration').length, fill: 'var(--chart-2)' },
    { name: 'Parallel', value: projects.filter(p => p.status === 'parallel').length, fill: 'var(--chart-3)' },
    { name: 'Completed', value: stats.completed, fill: 'var(--chart-1)' }
  ]

  const handleOpenDialog = (project: ModernizationProject) => {
    setSelectedProject(project)
    setDialogOpen(true)
  }

  const handleStatusChange = (projectId: string, newStatus: ModernizationProject["status"]) => {
    setProjects(prev => prev.map(p => 
      p.id === projectId ? { ...p, status: newStatus } : p
    ))
    if (selectedProject?.id === projectId) {
      setSelectedProject(prev => prev ? { ...prev, status: newStatus } : null)
    }
    showToast(`Project status updated to ${statusConfig[newStatus].label}`)
  }

  const handleToggleParallel = (projectId: string) => {
    setProjects(prev => prev.map(p => 
      p.id === projectId ? { ...p, parallelRunning: !p.parallelRunning } : p
    ))
    const project = projects.find(p => p.id === projectId)
    showToast(project?.parallelRunning ? "Parallel mode disabled" : "Parallel mode enabled")
  }

  const handleProgressUpdate = (projectId: string, delta: number) => {
    setProjects(prev => prev.map(p => 
      p.id === projectId ? { ...p, progress: Math.min(100, Math.max(0, p.progress + delta)) } : p
    ))
    if (selectedProject?.id === projectId) {
      setSelectedProject(prev => prev ? { ...prev, progress: Math.min(100, Math.max(0, prev.progress + delta)) } : null)
    }
    showToast(`Progress updated`)
  }

  const handleSaveNotes = (projectId: string) => {
    showToast("Notes saved successfully")
  }

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-2 fade-in duration-300">
          <div className="bg-primary text-primary-foreground px-4 py-3 rounded-lg shadow-lg flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Scale and Growth</h2>
          <p className="text-sm text-muted-foreground">
            Scenario 4: Manage coexistence of legacy and modern systems during extended modernization periods
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-44 bg-secondary">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              <SelectItem value="planning">Planning</SelectItem>
              <SelectItem value="migration">Migration</SelectItem>
              <SelectItem value="parallel">Parallel Running</SelectItem>
              <SelectItem value="cutover">Cutover</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Projects</p>
                <p className="text-2xl font-bold text-foreground">{stats.inProgress}</p>
              </div>
              <div className="rounded-lg bg-chart-2/20 p-2">
                <GitBranch className="h-5 w-5 text-chart-2" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {stats.planning} in planning phase
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Parallel Systems</p>
                <p className="text-2xl font-bold text-foreground">{stats.parallelRunning}</p>
              </div>
              <div className="rounded-lg bg-chart-3/20 p-2">
                <ArrowLeftRight className="h-5 w-5 text-chart-3" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Legacy + Modern running together
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Progress</p>
                <p className="text-2xl font-bold text-foreground">{stats.avgProgress}%</p>
              </div>
              <div className="rounded-lg bg-primary/20 p-2">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
            </div>
            <Progress value={stats.avgProgress} className="mt-3 h-1.5" />
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Risk</p>
                <p className="text-2xl font-bold text-foreground">{stats.highRisk}</p>
              </div>
              <div className="rounded-lg bg-destructive/20 p-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Projects requiring attention
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Complexity Trend */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Architecture Complexity Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={complexityTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--popover)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--popover-foreground)'
                    }}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="legacy"
                    stackId="1"
                    stroke="var(--destructive)"
                    fill="var(--destructive)"
                    fillOpacity={0.3}
                    name="Legacy"
                  />
                  <Area
                    type="monotone"
                    dataKey="hybrid"
                    stackId="1"
                    stroke="var(--chart-3)"
                    fill="var(--chart-3)"
                    fillOpacity={0.5}
                    name="Hybrid/Parallel"
                  />
                  <Area
                    type="monotone"
                    dataKey="modern"
                    stackId="1"
                    stroke="var(--chart-1)"
                    fill="var(--chart-1)"
                    fillOpacity={0.5}
                    name="Modern"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Status Distribution */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Project Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--popover)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--popover-foreground)'
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Projects List */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-foreground">Modernization Projects</h3>
        {filteredProjects.length === 0 ? (
          <Card className="bg-card border-border">
            <CardContent className="py-8 text-center text-muted-foreground">
              No projects found for this filter
            </CardContent>
          </Card>
        ) : (
          filteredProjects.map((project) => {
            const StatusIcon = statusConfig[project.status].icon
            return (
              <Card 
                key={project.id} 
                className="bg-card border-border cursor-pointer transition-all hover:border-primary/50"
                onClick={() => handleOpenDialog(project)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className={cn(
                        "rounded-lg p-2 mt-0.5",
                        statusConfig[project.status].bg
                      )}>
                        <StatusIcon className={cn("h-5 w-5", statusConfig[project.status].color)} />
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-medium text-foreground">{project.name}</h4>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground pt-1">
                          <span className="flex items-center gap-1">
                            <Layers className="h-3 w-3" />
                            {project.legacySystemName}
                          </span>
                          {project.modernSystemName && (
                            <>
                              <ArrowRight className="h-3 w-3" />
                              <span className="flex items-center gap-1">
                                <Target className="h-3 w-3" />
                                {project.modernSystemName}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="flex items-center gap-2">
                        <Badge className={complexityColors[project.complexity]}>
                          {project.complexity}
                        </Badge>
                        <Badge variant="outline" className={riskColors[project.riskLevel]}>
                          {project.riskLevel} risk
                        </Badge>
                      </div>
                      {project.parallelRunning && (
                        <Badge variant="outline" className="text-chart-3 border-chart-3/30">
                          <ArrowLeftRight className="mr-1 h-3 w-3" />
                          Parallel Running
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-medium text-foreground">{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-2" />
                    <div className="flex items-center justify-between text-xs text-muted-foreground mt-2">
                      <span>Started: {project.startDate}</span>
                      <span>Target: {project.targetDate}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>

      {/* Project Detail Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg bg-card">
          {selectedProject && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {selectedProject.name}
                  <Badge className={complexityColors[selectedProject.complexity]}>
                    {selectedProject.complexity}
                  </Badge>
                </DialogTitle>
                <DialogDescription>{selectedProject.description}</DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                {/* Status Control */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Project Status</Label>
                  <div className="flex flex-wrap gap-2">
                    {(["planning", "migration", "parallel", "cutover", "completed"] as const).map(status => (
                      <Button
                        key={status}
                        variant={selectedProject.status === status ? "default" : "outline"}
                        size="sm"
                        className={cn(
                          "text-xs",
                          selectedProject.status !== status && "bg-transparent"
                        )}
                        onClick={() => handleStatusChange(selectedProject.id, status)}
                      >
                        {statusConfig[status].label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Parallel Running Toggle */}
                <div className="flex items-center justify-between rounded-lg bg-secondary/50 p-3">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-medium">Parallel Running Mode</Label>
                    <p className="text-xs text-muted-foreground">
                      Legacy and modern systems running simultaneously
                    </p>
                  </div>
                  <Switch
                    checked={selectedProject.parallelRunning}
                    onCheckedChange={() => handleToggleParallel(selectedProject.id)}
                  />
                </div>

                {/* Progress Control */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Progress: {selectedProject.progress}%</Label>
                  <Progress value={selectedProject.progress} className="h-2" />
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 bg-transparent"
                      onClick={() => handleProgressUpdate(selectedProject.id, -10)}
                    >
                      -10%
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 bg-transparent"
                      onClick={() => handleProgressUpdate(selectedProject.id, -5)}
                    >
                      -5%
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 bg-transparent"
                      onClick={() => handleProgressUpdate(selectedProject.id, 5)}
                    >
                      +5%
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 bg-transparent"
                      onClick={() => handleProgressUpdate(selectedProject.id, 10)}
                    >
                      +10%
                    </Button>
                  </div>
                </div>

                {/* System Mapping */}
                <div className="rounded-lg bg-secondary/50 p-3 space-y-2">
                  <Label className="text-sm font-medium">System Mapping</Label>
                  <div className="flex items-center gap-2 text-sm">
                    <Badge variant="outline" className="text-destructive border-destructive/30">
                      Legacy
                    </Badge>
                    <span className="text-foreground">{selectedProject.legacySystemName}</span>
                  </div>
                  {selectedProject.modernSystemName && (
                    <div className="flex items-center gap-2 text-sm">
                      <Badge variant="outline" className="text-chart-1 border-chart-1/30">
                        Modern
                      </Badge>
                      <span className="text-foreground">{selectedProject.modernSystemName}</span>
                    </div>
                  )}
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Project Notes</Label>
                  <Textarea
                    placeholder="Add notes about this modernization project..."
                    value={notes[selectedProject.id] || ""}
                    onChange={(e) => setNotes(prev => ({ ...prev, [selectedProject.id]: e.target.value }))}
                    className="bg-secondary"
                  />
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setDialogOpen(false)} className="bg-transparent">
                  Close
                </Button>
                <Button onClick={() => handleSaveNotes(selectedProject.id)}>
                  Save Changes
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
