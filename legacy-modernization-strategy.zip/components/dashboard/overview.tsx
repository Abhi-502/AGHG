"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { StatCard } from "./stat-card"
import { cn } from "@/lib/utils"
import { legacySystems, changeRequests, bypassIncidents, systemHealthMetrics, dependencyMetrics } from "@/lib/mock-data"
import type { TabType } from "@/lib/types"
import {
  Layers,
  Clock,
  AlertTriangle,
  Zap,
  ArrowRight,
  CircleDot,
  CheckCircle2,
  RefreshCw
} from "lucide-react"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ComposedChart,
  Line
} from "recharts"

interface OverviewProps {
  onNavigate: (tab: TabType) => void
}

const agilityTrendData = [
  { month: 'Aug', score: 42, target: 70 },
  { month: 'Sep', score: 45, target: 70 },
  { month: 'Oct', score: 43, target: 70 },
  { month: 'Nov', score: 48, target: 70 },
  { month: 'Dec', score: 46, target: 70 },
  { month: 'Jan', score: 52, target: 70 }
]

const operationalHealthData = systemHealthMetrics.map(m => ({
  metric: m.category,
  score: m.score,
  fullMark: 100
}))

export function Overview({ onNavigate }: OverviewProps) {
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  const showToast = useCallback((message: string) => {
    setToastMessage(message)
    setTimeout(() => setToastMessage(null), 3000)
  }, [])

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      setIsRefreshing(false)
      showToast("Dashboard data refreshed")
    }, 1500)
  }

  const stats = {
    totalSystems: legacySystems.length,
    criticalSystems: legacySystems.filter(s => s.criticality === 'critical').length,
    avgCoupling: Math.round(legacySystems.reduce((acc, s) => acc + s.couplingScore, 0) / legacySystems.length),
    activeChanges: changeRequests.filter(r => r.status === 'in-progress').length,
    blockedChanges: changeRequests.filter(r => r.status === 'blocked').length,
    activeBypass: bypassIncidents.filter(i => i.status === 'active').length,
    criticalBypass: bypassIncidents.filter(i => i.riskLevel === 'critical' && i.status === 'active').length,
    agilityScore: 52
  }

  const criticalSystems = legacySystems
    .filter(s => s.riskScore > 60)
    .sort((a, b) => b.riskScore - a.riskScore)
    .slice(0, 4)

  const recentIncidents = bypassIncidents
    .filter(i => i.status === 'active')
    .slice(0, 3)

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-2 fade-in duration-300">
          <div className="bg-primary text-primary-foreground px-4 py-3 rounded-lg shadow-lg flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Infrastructure Overview</h2>
          <p className="text-sm text-muted-foreground">
            Monitor legacy system health, agility constraints, and modernization progress
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing} className="gap-2 bg-transparent">
          <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
          {isRefreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Agility Score"
          value={`${stats.agilityScore}%`}
          change={{ value: 8, trend: 'up' }}
          icon={Zap}
          iconColor="text-primary"
          subtitle="vs. 70% target"
          onClick={() => onNavigate('dependencies')}
        />
        <StatCard
          title="Critical Systems"
          value={stats.criticalSystems}
          change={{ value: 0, trend: 'stable' }}
          icon={Layers}
          iconColor="text-chart-3"
          subtitle={`${stats.totalSystems} total systems`}
          onClick={() => onNavigate('dependencies')}
        />
        <StatCard
          title="Blocked Changes"
          value={stats.blockedChanges}
          change={{ value: 15, trend: 'down' }}
          icon={Clock}
          iconColor="text-destructive"
          subtitle={`${stats.activeChanges} in progress`}
          onClick={() => onNavigate('timeline')}
        />
        <StatCard
          title="Active Bypasses"
          value={stats.activeBypass}
          change={{ value: 12, trend: 'up' }}
          icon={AlertTriangle}
          iconColor="text-chart-3"
          subtitle={`${stats.criticalBypass} critical risk`}
          onClick={() => onNavigate('bypass')}
        />
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Agility Trend */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base font-medium">Agility Score Trend</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('dependencies')}>
              View Details
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={agilityTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--popover)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--popover-foreground)'
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="target"
                    fill="var(--primary)"
                    fillOpacity={0.1}
                    stroke="var(--primary)"
                    strokeDasharray="5 5"
                    name="Target"
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="var(--chart-1)"
                    strokeWidth={2}
                    dot={{ fill: 'var(--chart-1)', strokeWidth: 2 }}
                    name="Agility Score"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Operational Health Radar */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base font-medium">Operational Health</CardTitle>
            <Badge variant="outline" className="text-chart-3 border-chart-3/30">
              Needs Attention
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={operationalHealthData}>
                  <PolarGrid stroke="var(--border)" />
                  <PolarAngleAxis 
                    dataKey="metric" 
                    stroke="var(--muted-foreground)" 
                    fontSize={11}
                    tick={{ fill: 'var(--muted-foreground)' }}
                  />
                  <PolarRadiusAxis 
                    angle={30} 
                    domain={[0, 100]} 
                    stroke="var(--muted-foreground)" 
                    fontSize={10}
                  />
                  <Radar
                    name="Health Score"
                    dataKey="score"
                    stroke="var(--primary)"
                    fill="var(--primary)"
                    fillOpacity={0.3}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Critical Systems & Recent Activity */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* High-Risk Systems */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base font-medium">High-Risk Systems</CardTitle>
              <p className="text-sm text-muted-foreground">Systems requiring attention</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => onNavigate('dependencies')} className="bg-transparent">
              View All
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {criticalSystems.map((system) => (
              <div 
                key={system.id} 
                className="flex items-center justify-between rounded-lg bg-secondary/50 p-3 transition-colors hover:bg-secondary cursor-pointer"
                onClick={() => onNavigate('dependencies')}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "h-2 w-2 rounded-full",
                    system.status === 'stable' ? "bg-chart-1" :
                    system.status === 'degraded' ? "bg-chart-3" : "bg-destructive"
                  )} />
                  <div>
                    <p className="text-sm font-medium text-foreground">{system.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {system.age}y old, {system.dependents.length} dependents
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">{system.riskScore}%</p>
                    <p className="text-xs text-muted-foreground">Risk Score</p>
                  </div>
                  <Progress 
                    value={system.riskScore} 
                    className="w-16 h-1.5"
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Bypass Incidents */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base font-medium">Active Bypass Incidents</CardTitle>
              <p className="text-sm text-muted-foreground">Workarounds requiring review</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => onNavigate('bypass')} className="bg-transparent">
              View All
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentIncidents.map((incident) => (
              <div 
                key={incident.id} 
                className="flex items-center justify-between rounded-lg bg-secondary/50 p-3 transition-colors hover:bg-secondary cursor-pointer"
                onClick={() => onNavigate('bypass')}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "rounded-lg p-1.5",
                    incident.riskLevel === 'critical' ? "bg-destructive/20" : "bg-chart-3/20"
                  )}>
                    <AlertTriangle className={cn(
                      "h-4 w-4",
                      incident.riskLevel === 'critical' ? "text-destructive" : "text-chart-3"
                    )} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground capitalize">
                      {incident.type.replace('-', ' ')}
                    </p>
                    <p className="text-xs text-muted-foreground line-clamp-1">
                      {incident.systemName}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge 
                    variant="outline" 
                    className={cn(
                      incident.riskLevel === 'critical' 
                        ? "text-destructive border-destructive/30" 
                        : "text-chart-3 border-chart-3/30"
                    )}
                  >
                    {incident.riskLevel}
                  </Badge>
                  {incident.dataConsistencyRisk && (
                    <CircleDot className="h-4 w-4 text-destructive" />
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Dependency Metrics */}
      <Card className="bg-card border-border">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base font-medium">System Coupling Analysis</CardTitle>
            <p className="text-sm text-muted-foreground">
              Coupling scores indicate integration complexity
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => onNavigate('dependencies')} className="bg-transparent">
            Analyze Dependencies
          </Button>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dependencyMetrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--popover)',
                    border: '1px solid var(--border)',
                    borderRadius: '8px',
                    color: 'var(--popover-foreground)'
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="couplingScore"
                  stroke="var(--destructive)"
                  fill="var(--destructive)"
                  fillOpacity={0.2}
                  name="Coupling Score"
                />
                <Area
                  type="monotone"
                  dataKey="changeVelocity"
                  stroke="var(--chart-1)"
                  fill="var(--chart-1)"
                  fillOpacity={0.2}
                  name="Change Velocity"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
