"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"
import { legacySystems, dependencyMetrics } from "@/lib/mock-data"
import type { LegacySystem } from "@/lib/types"
import {
  AlertTriangle,
  ArrowRight,
  CircleDot,
  ExternalLink,
  Filter,
  Info,
  Layers,
  Link2,
  Zap,
  TrendingUp,
  RefreshCw,
  CheckCircle2,
  FileText,
  Settings
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts"

const priorityColors = {
  critical: "bg-destructive text-destructive-foreground",
  high: "bg-chart-3 text-foreground",
  medium: "bg-chart-2 text-foreground",
  low: "bg-chart-1 text-primary-foreground"
}

const statusColors = {
  stable: "bg-chart-1/20 text-chart-1 border-chart-1/30",
  degraded: "bg-chart-3/20 text-chart-3 border-chart-3/30",
  "at-risk": "bg-destructive/20 text-destructive border-destructive/30"
}

export function DependencyAnalysis() {
  const [selectedSystem, setSelectedSystem] = useState<LegacySystem | null>(null)
  const [filterCriticality, setFilterCriticality] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("coupling")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  const showToast = useCallback((message: string) => {
    setToastMessage(message)
    setTimeout(() => setToastMessage(null), 3000)
  }, [])

  const filteredSystems = legacySystems
    .filter(s => filterCriticality === "all" || s.criticality === filterCriticality)
    .sort((a, b) => {
      switch (sortBy) {
        case "coupling": return b.couplingScore - a.couplingScore
        case "risk": return b.riskScore - a.riskScore
        case "age": return b.age - a.age
        case "dependents": return b.dependents.length - a.dependents.length
        default: return 0
      }
    })

  const runAnalysis = () => {
    setIsAnalyzing(true)
    setTimeout(() => {
      setIsAnalyzing(false)
      showToast("Analysis complete - 2 systems flagged for review")
    }, 2000)
  }

  const handleOpenDialog = (system: LegacySystem) => {
    setSelectedSystem(system)
    setDialogOpen(true)
  }

  const handleViewReport = () => {
    showToast("Generating full system report...")
    setTimeout(() => showToast("Report downloaded successfully"), 1500)
  }

  const handlePlanModernization = () => {
    showToast(`Modernization planning initiated for ${selectedSystem?.name}`)
    setDialogOpen(false)
  }

  const chartData = dependencyMetrics.map(m => ({
    ...m,
    agility: Math.round(100 - m.couplingScore * 0.6 - (100 - m.changeVelocity) * 0.4)
  }))

  const radarData = selectedSystem ? [
    { metric: 'Coupling', value: selectedSystem.couplingScore, fullMark: 100 },
    { metric: 'Risk', value: selectedSystem.riskScore, fullMark: 100 },
    { metric: 'Dependencies', value: Math.min(selectedSystem.dependencies.length * 20, 100), fullMark: 100 },
    { metric: 'Dependents', value: Math.min(selectedSystem.dependents.length * 15, 100), fullMark: 100 },
    { metric: 'Age Factor', value: Math.min(selectedSystem.age * 4, 100), fullMark: 100 },
  ] : []

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-2 fade-in duration-300">
          <div className="bg-primary text-primary-foreground px-4 py-3 rounded-lg shadow-lg flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Dependency Analysis</h2>
          <p className="text-sm text-muted-foreground">
            Identify which legacy dependencies most severely constrain agility
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterCriticality} onValueChange={setFilterCriticality}>
            <SelectTrigger className="w-40 bg-secondary">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Criticality" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Systems</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40 bg-secondary">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="coupling">Coupling Score</SelectItem>
              <SelectItem value="risk">Risk Score</SelectItem>
              <SelectItem value="age">System Age</SelectItem>
              <SelectItem value="dependents">Dependents</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={runAnalysis} disabled={isAnalyzing} className="gap-2">
            <RefreshCw className={cn("h-4 w-4", isAnalyzing && "animate-spin")} />
            {isAnalyzing ? "Analyzing..." : "Run Analysis"}
          </Button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Systems</p>
                <p className="text-2xl font-bold text-foreground">{filteredSystems.length}</p>
              </div>
              <div className="rounded-lg bg-chart-2/20 p-2">
                <Layers className="h-5 w-5 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Coupling</p>
                <p className="text-2xl font-bold text-foreground">
                  {Math.round(filteredSystems.reduce((a, s) => a + s.couplingScore, 0) / filteredSystems.length)}%
                </p>
              </div>
              <div className="rounded-lg bg-chart-3/20 p-2">
                <Link2 className="h-5 w-5 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Risk</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredSystems.filter(s => s.riskScore > 60).length}
                </p>
              </div>
              <div className="rounded-lg bg-destructive/20 p-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Degraded</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredSystems.filter(s => s.status !== 'stable').length}
                </p>
              </div>
              <div className="rounded-lg bg-chart-1/20 p-2">
                <Settings className="h-5 w-5 text-chart-1" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Coupling Score Chart */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base font-medium">
            <Zap className="h-4 w-4 text-chart-3" />
            Agility Constraint Index
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis type="number" domain={[0, 100]} stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis dataKey="name" type="category" width={100} stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--popover)',
                    border: '1px solid var(--border)',
                    borderRadius: '8px',
                    color: 'var(--popover-foreground)'
                  }}
                  formatter={(value: number, name: string) => [
                    `${value}%`,
                    name === 'couplingScore' ? 'Coupling' : name === 'agility' ? 'Agility Impact' : name
                  ]}
                />
                <Bar dataKey="couplingScore" name="Coupling Score" radius={[0, 4, 4, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.couplingScore > 80 ? 'var(--destructive)' : entry.couplingScore > 60 ? 'var(--chart-3)' : 'var(--chart-1)'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Systems Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredSystems.length === 0 ? (
          <Card className="col-span-full bg-card border-border">
            <CardContent className="py-8 text-center text-muted-foreground">
              No systems found for this filter
            </CardContent>
          </Card>
        ) : (
          filteredSystems.map((system) => (
            <Card 
              key={system.id}
              className={cn(
                "cursor-pointer bg-card border-border transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5",
                selectedSystem?.id === system.id && "border-primary"
              )}
              onClick={() => handleOpenDialog(system)}
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <CircleDot className={cn(
                        "h-3 w-3",
                        system.status === 'stable' ? "text-chart-1" : 
                        system.status === 'degraded' ? "text-chart-3" : "text-destructive"
                      )} />
                      <h3 className="font-medium text-foreground">{system.name}</h3>
                    </div>
                    <p className="text-xs text-muted-foreground capitalize">{system.type}</p>
                  </div>
                  <Badge className={priorityColors[system.criticality]}>
                    {system.criticality}
                  </Badge>
                </div>

                <div className="mt-4 space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Coupling Score</span>
                      <span className="font-medium text-foreground">{system.couplingScore}%</span>
                    </div>
                    <Progress 
                      value={system.couplingScore} 
                      className="mt-1.5 h-1.5"
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Link2 className="h-3 w-3" />
                      <span>{system.dependencies.length} deps</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Layers className="h-3 w-3" />
                      <span>{system.dependents.length} dependents</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      <span>{system.age}y old</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <Badge variant="outline" className={cn("text-xs", statusColors[system.status])}>
                    {system.status}
                  </Badge>
                  {system.riskScore > 70 && (
                    <Badge variant="outline" className="text-xs text-destructive border-destructive/30">
                      <AlertTriangle className="mr-1 h-3 w-3" />
                      High Risk
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* System Detail Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl bg-card">
          {selectedSystem && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <CircleDot className={cn(
                    "h-4 w-4",
                    selectedSystem.status === 'stable' ? "text-chart-1" : 
                    selectedSystem.status === 'degraded' ? "text-chart-3" : "text-destructive"
                  )} />
                  {selectedSystem.name}
                  <Badge className={priorityColors[selectedSystem.criticality]}>
                    {selectedSystem.criticality}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  System analysis and dependency mapping
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-6 py-4 md:grid-cols-2">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">System Metrics</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Coupling Score</span>
                        <span className="font-medium text-foreground">{selectedSystem.couplingScore}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Risk Score</span>
                        <span className="font-medium text-foreground">{selectedSystem.riskScore}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">System Age</span>
                        <span className="font-medium text-foreground">{selectedSystem.age} years</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Change Frequency</span>
                        <span className="font-medium text-foreground">{selectedSystem.changeFrequency}/month</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Modified</span>
                        <span className="font-medium text-foreground">{selectedSystem.lastModified}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">Dependencies ({selectedSystem.dependencies.length})</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedSystem.dependencies.map(depId => {
                        const dep = legacySystems.find(s => s.id === depId)
                        return dep ? (
                          <Badge 
                            key={depId} 
                            variant="outline" 
                            className="text-xs cursor-pointer hover:bg-secondary"
                            onClick={() => {
                              setSelectedSystem(dep)
                            }}
                          >
                            <ArrowRight className="mr-1 h-3 w-3" />
                            {dep.name}
                          </Badge>
                        ) : null
                      })}
                      {selectedSystem.dependencies.length === 0 && (
                        <span className="text-sm text-muted-foreground">No dependencies</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">Dependents ({selectedSystem.dependents.length})</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedSystem.dependents.map(depId => {
                        const dep = legacySystems.find(s => s.id === depId)
                        return dep ? (
                          <Badge 
                            key={depId} 
                            variant="secondary" 
                            className="text-xs cursor-pointer hover:bg-secondary/80"
                            onClick={() => {
                              setSelectedSystem(dep)
                            }}
                          >
                            {dep.name}
                          </Badge>
                        ) : null
                      })}
                      {selectedSystem.dependents.length === 0 && (
                        <span className="text-sm text-muted-foreground">No dependents</span>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-foreground mb-2">Risk Profile</h4>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="var(--border)" />
                        <PolarAngleAxis dataKey="metric" stroke="var(--muted-foreground)" fontSize={11} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="var(--muted-foreground)" fontSize={10} />
                        <Radar
                          name="System"
                          dataKey="value"
                          stroke="var(--primary)"
                          fill="var(--primary)"
                          fillOpacity={0.3}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <DialogFooter className="flex justify-between border-t border-border pt-4">
                <Button variant="outline" className="gap-2 bg-transparent" onClick={handleViewReport}>
                  <FileText className="h-4 w-4" />
                  View Full Report
                </Button>
                <Button className="gap-2" onClick={handlePlanModernization}>
                  <ExternalLink className="h-4 w-4" />
                  Plan Modernization
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
