"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { bypassIncidents as initialBypassIncidents, legacySystems } from "@/lib/mock-data"
import type { BypassIncident } from "@/lib/types"
import {
  AlertTriangle,
  FileSpreadsheet,
  Code,
  Wrench,
  ExternalLink,
  CheckCircle2,
  Eye,
  Users,
  AlertCircle,
  Database,
  Activity,
  Bell,
  BellOff,
  ChevronRight,
  RefreshCw,
  X
} from "lucide-react"
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from "recharts"

const bypassTypeConfig = {
  "shadow-system": { 
    icon: FileSpreadsheet, 
    label: "Shadow System", 
    description: "External tools duplicating data/functionality" 
  },
  "script": { 
    icon: Code, 
    label: "Custom Script", 
    description: "Unauthorized automated data access" 
  },
  "manual-workaround": { 
    icon: Wrench, 
    label: "Manual Workaround", 
    description: "Manual processes bypassing official flows" 
  },
  "external-tool": { 
    icon: ExternalLink, 
    label: "External Tool", 
    description: "Third-party tools used instead of internal systems" 
  }
}

const riskColors = {
  critical: "text-destructive bg-destructive/20 border-destructive/30",
  high: "text-chart-3 bg-chart-3/20 border-chart-3/30",
  medium: "text-chart-2 bg-chart-2/20 border-chart-2/30",
  low: "text-chart-1 bg-chart-1/20 border-chart-1/30"
}

const statusColors = {
  active: "bg-destructive/20 text-destructive border-destructive/30",
  monitoring: "bg-chart-3/20 text-chart-3 border-chart-3/30",
  resolved: "bg-chart-1/20 text-chart-1 border-chart-1/30"
}

export function BypassDetection() {
  const [incidents, setIncidents] = useState<BypassIncident[]>(initialBypassIncidents)
  const [viewType, setViewType] = useState<"all" | "active" | "monitoring" | "resolved">("all")
  const [autoDetectionEnabled, setAutoDetectionEnabled] = useState(true)
  const [alertsEnabled, setAlertsEnabled] = useState(true)
  const [remediationNotes, setRemediationNotes] = useState<Record<string, string>>({})
  const [isScanning, setIsScanning] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [openAccordion, setOpenAccordion] = useState<string | undefined>(undefined)

  const showToast = useCallback((message: string) => {
    setToastMessage(message)
    setTimeout(() => setToastMessage(null), 3000)
  }, [])

  const filteredIncidents = incidents.filter(
    i => viewType === "all" || i.status === viewType
  )

  const stats = {
    total: incidents.length,
    active: incidents.filter(i => i.status === 'active').length,
    monitoring: incidents.filter(i => i.status === 'monitoring').length,
    resolved: incidents.filter(i => i.status === 'resolved').length,
    criticalRisk: incidents.filter(i => i.riskLevel === 'critical' && i.status === 'active').length,
    dataRisk: incidents.filter(i => i.dataConsistencyRisk && i.status === 'active').length,
    totalAffected: incidents.filter(i => i.status === 'active').reduce((acc, i) => acc + i.affectedUsers, 0),
    totalFrequency: incidents.reduce((acc, i) => acc + i.frequency, 0)
  }

  const typeDistribution = Object.entries(bypassTypeConfig).map(([type, config]) => ({
    name: config.label,
    value: incidents.filter(i => i.type === type).length,
    fill: type === 'shadow-system' ? 'var(--destructive)' : 
          type === 'script' ? 'var(--chart-3)' : 
          type === 'manual-workaround' ? 'var(--chart-2)' : 'var(--chart-1)'
  }))

  const systemRiskData = legacySystems.slice(0, 5).map(system => ({
    name: system.name.split(' ')[0],
    bypasses: incidents.filter(i => i.systemId === system.id).length,
    risk: incidents.filter(i => i.systemId === system.id && (i.riskLevel === 'critical' || i.riskLevel === 'high')).length
  }))

  const runScan = () => {
    setIsScanning(true)
    setTimeout(() => {
      setIsScanning(false)
      showToast("Scan completed - No new bypass incidents detected")
    }, 2000)
  }

  const handleSetMonitoring = (incidentId: string) => {
    setIncidents(prev => prev.map(i => 
      i.id === incidentId ? { ...i, status: 'monitoring' as const } : i
    ))
    showToast("Incident set to monitoring status")
  }

  const handleResolve = (incidentId: string) => {
    const note = remediationNotes[incidentId]
    if (!note?.trim()) {
      showToast("Please add a remediation note before resolving")
      return
    }
    setIncidents(prev => prev.map(i => 
      i.id === incidentId ? { ...i, status: 'resolved' as const } : i
    ))
    setRemediationNotes(prev => {
      const copy = { ...prev }
      delete copy[incidentId]
      return copy
    })
    showToast("Incident marked as resolved")
  }

  const handleReactivate = (incidentId: string) => {
    setIncidents(prev => prev.map(i => 
      i.id === incidentId ? { ...i, status: 'active' as const } : i
    ))
    showToast("Incident reactivated")
  }

  const handleDismissAlert = () => {
    showToast("Alert acknowledged")
  }

  const handleRemediationNoteChange = (incidentId: string, value: string) => {
    setRemediationNotes(prev => ({ ...prev, [incidentId]: value }))
  }

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-2 fade-in duration-300">
          <div className="bg-primary text-primary-foreground px-4 py-3 rounded-lg shadow-lg flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Bypass Detection</h2>
          <p className="text-sm text-muted-foreground">
            Detect and respond to workarounds that bypass slow legacy processes
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch
              id="auto-detection"
              checked={autoDetectionEnabled}
              onCheckedChange={(checked) => {
                setAutoDetectionEnabled(checked)
                showToast(checked ? "Auto detection enabled" : "Auto detection disabled")
              }}
            />
            <Label htmlFor="auto-detection" className="text-sm text-muted-foreground">
              Auto Detection
            </Label>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              id="alerts"
              checked={alertsEnabled}
              onCheckedChange={(checked) => {
                setAlertsEnabled(checked)
                showToast(checked ? "Alerts enabled" : "Alerts disabled")
              }}
            />
            <Label htmlFor="alerts" className="text-sm text-muted-foreground flex items-center gap-1">
              {alertsEnabled ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
              Alerts
            </Label>
          </div>
          <Button onClick={runScan} disabled={isScanning} className="gap-2">
            <RefreshCw className={cn("h-4 w-4", isScanning && "animate-spin")} />
            {isScanning ? "Scanning..." : "Run Scan"}
          </Button>
        </div>
      </div>

      {/* Critical Alert */}
      {stats.criticalRisk > 0 && alertsEnabled && (
        <Alert className="border-destructive/50 bg-destructive/10">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertTitle className="text-destructive flex items-center justify-between">
            <span>Critical Bypass Activity Detected</span>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={handleDismissAlert}>
              <X className="h-4 w-4" />
            </Button>
          </AlertTitle>
          <AlertDescription className="text-muted-foreground">
            {stats.criticalRisk} critical-risk bypass incidents require immediate attention. 
            {stats.dataRisk > 0 && ` ${stats.dataRisk} incidents pose data consistency risks.`}
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card 
          className={cn(
            "bg-card border-border transition-all cursor-pointer hover:border-primary/50",
            viewType === "active" && "border-primary"
          )}
          onClick={() => setViewType("active")}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Incidents</p>
                <p className="text-2xl font-bold text-foreground">{stats.active}</p>
              </div>
              <div className="rounded-lg bg-destructive/20 p-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {stats.criticalRisk} critical risk
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Affected Users</p>
                <p className="text-2xl font-bold text-foreground">{stats.totalAffected}</p>
              </div>
              <div className="rounded-lg bg-chart-3/20 p-2">
                <Users className="h-5 w-5 text-chart-3" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Across {stats.active} active incidents
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Data Risk Incidents</p>
                <p className="text-2xl font-bold text-foreground">{stats.dataRisk}</p>
              </div>
              <div className="rounded-lg bg-chart-2/20 p-2">
                <Database className="h-5 w-5 text-chart-2" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Data consistency at risk
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Bypass Events</p>
                <p className="text-2xl font-bold text-foreground">{stats.totalFrequency}</p>
              </div>
              <div className="rounded-lg bg-chart-1/20 p-2">
                <Activity className="h-5 w-5 text-chart-1" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Last 30 days
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Bypass Type Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={typeDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {typeDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--popover)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--popover-foreground)'
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Bypass by System</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={systemRiskData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={11} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--popover)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--popover-foreground)'
                    }}
                  />
                  <Bar dataKey="bypasses" fill="var(--chart-2)" name="Total Bypasses" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="risk" fill="var(--destructive)" name="High Risk" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Filter */}
      <Tabs value={viewType} onValueChange={(v) => setViewType(v as typeof viewType)}>
        <TabsList className="bg-secondary">
          <TabsTrigger value="all" className="text-xs">
            All ({stats.total})
          </TabsTrigger>
          <TabsTrigger value="active" className="text-xs">
            <AlertCircle className="mr-1 h-3 w-3" />
            Active ({stats.active})
          </TabsTrigger>
          <TabsTrigger value="monitoring" className="text-xs">
            <Eye className="mr-1 h-3 w-3" />
            Monitoring ({stats.monitoring})
          </TabsTrigger>
          <TabsTrigger value="resolved" className="text-xs">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            Resolved ({stats.resolved})
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Incidents List */}
      <div className="space-y-4">
        {filteredIncidents.length === 0 ? (
          <Card className="bg-card border-border">
            <CardContent className="py-8 text-center text-muted-foreground">
              No incidents found for this filter
            </CardContent>
          </Card>
        ) : (
          filteredIncidents.map((incident) => {
            const TypeIcon = bypassTypeConfig[incident.type].icon
            return (
              <Card key={incident.id} className="bg-card border-border">
                <CardContent className="p-0">
                  <Accordion 
                    type="single" 
                    collapsible 
                    value={openAccordion}
                    onValueChange={setOpenAccordion}
                  >
                    <AccordionItem value={incident.id} className="border-0">
                      <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-secondary/50">
                        <div className="flex flex-1 items-center justify-between pr-4">
                          <div className="flex items-center gap-4">
                            <div className={cn(
                              "rounded-lg p-2",
                              incident.riskLevel === 'critical' ? "bg-destructive/20" :
                              incident.riskLevel === 'high' ? "bg-chart-3/20" :
                              incident.riskLevel === 'medium' ? "bg-chart-2/20" : "bg-chart-1/20"
                            )}>
                              <TypeIcon className={cn(
                                "h-5 w-5",
                                incident.riskLevel === 'critical' ? "text-destructive" :
                                incident.riskLevel === 'high' ? "text-chart-3" :
                                incident.riskLevel === 'medium' ? "text-chart-2" : "text-chart-1"
                              )} />
                            </div>
                            <div className="text-left">
                              <p className="font-medium text-foreground">
                                {bypassTypeConfig[incident.type].label}
                              </p>
                              <p className="text-sm text-muted-foreground line-clamp-1">
                                {incident.description}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className={riskColors[incident.riskLevel]}>
                              {incident.riskLevel}
                            </Badge>
                            <Badge variant="outline" className={statusColors[incident.status]}>
                              {incident.status}
                            </Badge>
                            {incident.dataConsistencyRisk && (
                              <Badge variant="outline" className="text-destructive border-destructive/30">
                                <Database className="mr-1 h-3 w-3" />
                                Data Risk
                              </Badge>
                            )}
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-5 pb-5">
                        <div className="grid gap-6 md:grid-cols-2">
                          <div className="space-y-4">
                            <div>
                              <h4 className="text-sm font-medium text-foreground mb-2">Incident Details</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Affected System</span>
                                  <span className="text-foreground">{incident.systemName}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Detected Date</span>
                                  <span className="text-foreground">{incident.detectedDate}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Usage Frequency</span>
                                  <span className="text-foreground">{incident.frequency} events/month</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Affected Users</span>
                                  <span className="text-foreground">{incident.affectedUsers} users</span>
                                </div>
                              </div>
                            </div>

                            <div>
                              <h4 className="text-sm font-medium text-foreground mb-2">Root Cause Analysis</h4>
                              <p className="text-sm text-muted-foreground">
                                {bypassTypeConfig[incident.type].description}. This bypass behavior indicates 
                                that users are finding the official process too slow or cumbersome for their needs.
                              </p>
                            </div>
                          </div>

                          <div className="space-y-4">
                            <div>
                              <h4 className="text-sm font-medium text-foreground mb-2">Recommended Actions</h4>
                              <ul className="space-y-2 text-sm text-muted-foreground">
                                <li className="flex items-start gap-2">
                                  <ChevronRight className="h-4 w-4 mt-0.5 text-primary" />
                                  <span>Investigate root cause in {incident.systemName}</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <ChevronRight className="h-4 w-4 mt-0.5 text-primary" />
                                  <span>Engage with affected users to understand needs</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <ChevronRight className="h-4 w-4 mt-0.5 text-primary" />
                                  <span>Evaluate legacy system improvement options</span>
                                </li>
                                {incident.dataConsistencyRisk && (
                                  <li className="flex items-start gap-2">
                                    <ChevronRight className="h-4 w-4 mt-0.5 text-destructive" />
                                    <span className="text-destructive">Urgent: Implement data reconciliation</span>
                                  </li>
                                )}
                              </ul>
                            </div>

                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Add Remediation Note</Label>
                              <Textarea
                                placeholder="Document remediation actions taken..."
                                value={remediationNotes[incident.id] || ""}
                                onChange={(e) => handleRemediationNoteChange(incident.id, e.target.value)}
                                className="bg-secondary"
                              />
                            </div>

                            <div className="flex gap-2">
                              {incident.status === 'active' && (
                                <>
                                  <Button 
                                    variant="outline" 
                                    className="flex-1 gap-2 bg-transparent"
                                    onClick={() => handleSetMonitoring(incident.id)}
                                  >
                                    <Eye className="h-4 w-4" />
                                    Set to Monitoring
                                  </Button>
                                  <Button 
                                    className="flex-1 gap-2"
                                    onClick={() => handleResolve(incident.id)}
                                  >
                                    <CheckCircle2 className="h-4 w-4" />
                                    Mark Resolved
                                  </Button>
                                </>
                              )}
                              {incident.status === 'monitoring' && (
                                <>
                                  <Button 
                                    variant="outline" 
                                    className="flex-1 gap-2 bg-transparent"
                                    onClick={() => handleReactivate(incident.id)}
                                  >
                                    <AlertTriangle className="h-4 w-4" />
                                    Reactivate
                                  </Button>
                                  <Button 
                                    className="flex-1 gap-2"
                                    onClick={() => handleResolve(incident.id)}
                                  >
                                    <CheckCircle2 className="h-4 w-4" />
                                    Mark Resolved
                                  </Button>
                                </>
                              )}
                              {incident.status === 'resolved' && (
                                <Button 
                                  variant="outline" 
                                  className="flex-1 gap-2 bg-transparent"
                                  onClick={() => handleReactivate(incident.id)}
                                >
                                  <AlertTriangle className="h-4 w-4" />
                                  Reopen Incident
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}
