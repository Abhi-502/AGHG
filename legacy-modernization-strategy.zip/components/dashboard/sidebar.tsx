"use client"

import { cn } from "@/lib/utils"
import type { TabType } from "@/lib/types"
import {
  LayoutDashboard,
  Network,
  Clock,
  AlertTriangle,
  Settings,
  HelpCircle,
  Layers,
  ChevronLeft,
  ChevronRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface SidebarProps {
  activeTab: TabType
  onTabChange: (tab: TabType) => void
  collapsed: boolean
  onCollapsedChange: (collapsed: boolean) => void
}

const mainNavItems = [
  { id: 'overview' as TabType, label: 'Overview', icon: LayoutDashboard },
  { id: 'dependencies' as TabType, label: 'Dependencies', icon: Network },
  { id: 'timeline' as TabType, label: 'Timeline', icon: Clock },
  { id: 'bypass' as TabType, label: 'Bypass Detection', icon: AlertTriangle },
]

const bottomNavItems = [
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'help', label: 'Help', icon: HelpCircle },
]

export function Sidebar({ activeTab, onTabChange, collapsed, onCollapsedChange }: SidebarProps) {
  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 h-screen border-r border-border bg-sidebar transition-all duration-300",
          collapsed ? "w-16" : "w-64"
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className={cn(
            "flex h-16 items-center border-b border-border px-4",
            collapsed ? "justify-center" : "gap-3"
          )}>
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Layers className="h-5 w-5 text-primary-foreground" />
            </div>
            {!collapsed && (
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-foreground">LegacyMod</span>
                <span className="text-xs text-muted-foreground">Enterprise</span>
              </div>
            )}
          </div>

          {/* Main Navigation */}
          <nav className="flex-1 space-y-1 px-2 py-4">
            <div className={cn("mb-2 px-2", collapsed && "hidden")}>
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Main
              </span>
            </div>
            {mainNavItems.map((item) => {
              const Icon = item.icon
              const isActive = activeTab === item.id
              
              const button = (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                    collapsed && "justify-center px-2"
                  )}
                >
                  <Icon className={cn("h-5 w-5 shrink-0", isActive && "text-primary")} />
                  {!collapsed && <span>{item.label}</span>}
                </button>
              )

              if (collapsed) {
                return (
                  <Tooltip key={item.id}>
                    <TooltipTrigger asChild>{button}</TooltipTrigger>
                    <TooltipContent side="right" className="bg-popover text-popover-foreground">
                      {item.label}
                    </TooltipContent>
                  </Tooltip>
                )
              }

              return button
            })}
          </nav>

          {/* Bottom Navigation */}
          <div className="border-t border-border px-2 py-4">
            {bottomNavItems.map((item) => {
              const Icon = item.icon
              
              const button = (
                <button
                  key={item.id}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground",
                    collapsed && "justify-center px-2"
                  )}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  {!collapsed && <span>{item.label}</span>}
                </button>
              )

              if (collapsed) {
                return (
                  <Tooltip key={item.id}>
                    <TooltipTrigger asChild>{button}</TooltipTrigger>
                    <TooltipContent side="right" className="bg-popover text-popover-foreground">
                      {item.label}
                    </TooltipContent>
                  </Tooltip>
                )
              }

              return button
            })}
          </div>

          {/* Collapse Toggle */}
          <div className="border-t border-border p-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onCollapsedChange(!collapsed)}
              className={cn(
                "w-full text-muted-foreground hover:text-foreground",
                collapsed ? "justify-center" : "justify-end"
              )}
            >
              {collapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <>
                  <span className="mr-2 text-xs">Collapse</span>
                  <ChevronLeft className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </div>
      </aside>
    </TooltipProvider>
  )
}
