export interface LegacySystem {
  id: string
  name: string
  type: 'mainframe' | 'database' | 'api' | 'service' | 'middleware'
  age: number
  criticality: 'critical' | 'high' | 'medium' | 'low'
  couplingScore: number
  lastModified: string
  dependencies: string[]
  dependents: string[]
  changeFrequency: number
  riskScore: number
  status: 'stable' | 'degraded' | 'at-risk'
}

export interface ChangeRequest {
  id: string
  title: string
  description: string
  systemId: string
  systemName: string
  requestedDate: string
  estimatedDays: number
  actualDays?: number
  status: 'pending' | 'in-progress' | 'completed' | 'blocked'
  blockers: string[]
  legacyImpact: 'high' | 'medium' | 'low'
  priority: 'critical' | 'high' | 'medium' | 'low'
}

export interface BypassIncident {
  id: string
  type: 'shadow-system' | 'manual-workaround' | 'external-tool' | 'script'
  description: string
  detectedDate: string
  systemId: string
  systemName: string
  frequency: number
  riskLevel: 'critical' | 'high' | 'medium' | 'low'
  status: 'active' | 'resolved' | 'monitoring'
  affectedUsers: number
  dataConsistencyRisk: boolean
}

export interface TimelineMetric {
  month: string
  planned: number
  actual: number
  blocked: number
}

export interface DependencyMetric {
  name: string
  couplingScore: number
  impactRadius: number
  changeVelocity: number
}

export interface SystemHealthMetric {
  category: string
  score: number
  trend: 'up' | 'down' | 'stable'
}

export type TabType = 'overview' | 'dependencies' | 'timeline' | 'bypass' | 'scale'

export interface ModernizationProject {
  id: string
  name: string
  description: string
  legacySystemId: string
  legacySystemName: string
  modernSystemId?: string
  modernSystemName?: string
  status: 'planning' | 'migration' | 'parallel' | 'cutover' | 'completed'
  progress: number
  startDate: string
  targetDate: string
  complexity: 'low' | 'medium' | 'high' | 'critical'
  riskLevel: 'low' | 'medium' | 'high'
  parallelRunning: boolean
}
