import type { 
  LegacySystem, 
  ChangeRequest, 
  BypassIncident, 
  TimelineMetric, 
  DependencyMetric,
  SystemHealthMetric,
  ModernizationProject
} from './types'

export const legacySystems: LegacySystem[] = [
  {
    id: 'sys-001',
    name: 'Core Banking Engine',
    type: 'mainframe',
    age: 25,
    criticality: 'critical',
    couplingScore: 92,
    lastModified: '2024-03-15',
    dependencies: ['sys-002', 'sys-003', 'sys-005'],
    dependents: ['sys-004', 'sys-006', 'sys-007', 'sys-008'],
    changeFrequency: 2,
    riskScore: 85,
    status: 'stable'
  },
  {
    id: 'sys-002',
    name: 'Customer Data Platform',
    type: 'database',
    age: 18,
    criticality: 'critical',
    couplingScore: 88,
    lastModified: '2024-06-22',
    dependencies: ['sys-003'],
    dependents: ['sys-001', 'sys-004', 'sys-005', 'sys-006'],
    changeFrequency: 5,
    riskScore: 78,
    status: 'stable'
  },
  {
    id: 'sys-003',
    name: 'Authentication Service',
    type: 'service',
    age: 12,
    criticality: 'critical',
    couplingScore: 75,
    lastModified: '2024-09-10',
    dependencies: [],
    dependents: ['sys-001', 'sys-002', 'sys-004', 'sys-005', 'sys-006', 'sys-007'],
    changeFrequency: 8,
    riskScore: 65,
    status: 'degraded'
  },
  {
    id: 'sys-004',
    name: 'Payment Gateway',
    type: 'api',
    age: 8,
    criticality: 'high',
    couplingScore: 68,
    lastModified: '2024-11-05',
    dependencies: ['sys-001', 'sys-002', 'sys-003'],
    dependents: ['sys-007', 'sys-008'],
    changeFrequency: 12,
    riskScore: 55,
    status: 'stable'
  },
  {
    id: 'sys-005',
    name: 'Report Generator',
    type: 'service',
    age: 15,
    criticality: 'medium',
    couplingScore: 52,
    lastModified: '2024-08-18',
    dependencies: ['sys-001', 'sys-002', 'sys-003'],
    dependents: ['sys-009'],
    changeFrequency: 3,
    riskScore: 45,
    status: 'at-risk'
  },
  {
    id: 'sys-006',
    name: 'Notification Engine',
    type: 'middleware',
    age: 10,
    criticality: 'medium',
    couplingScore: 45,
    lastModified: '2024-10-30',
    dependencies: ['sys-002', 'sys-003'],
    dependents: ['sys-007', 'sys-008', 'sys-009'],
    changeFrequency: 6,
    riskScore: 38,
    status: 'stable'
  },
  {
    id: 'sys-007',
    name: 'Mobile API Layer',
    type: 'api',
    age: 5,
    criticality: 'high',
    couplingScore: 35,
    lastModified: '2025-01-10',
    dependencies: ['sys-001', 'sys-003', 'sys-004', 'sys-006'],
    dependents: [],
    changeFrequency: 25,
    riskScore: 28,
    status: 'stable'
  },
  {
    id: 'sys-008',
    name: 'Batch Processing',
    type: 'service',
    age: 20,
    criticality: 'high',
    couplingScore: 72,
    lastModified: '2024-05-12',
    dependencies: ['sys-001', 'sys-004', 'sys-006'],
    dependents: [],
    changeFrequency: 1,
    riskScore: 70,
    status: 'degraded'
  }
]

export const changeRequests: ChangeRequest[] = [
  {
    id: 'cr-001',
    title: 'Add Real-time Analytics Endpoint',
    description: 'Integrate streaming analytics capability to core banking engine',
    systemId: 'sys-001',
    systemName: 'Core Banking Engine',
    requestedDate: '2025-01-05',
    estimatedDays: 45,
    status: 'blocked',
    blockers: ['Legacy COBOL dependencies', 'No test environment available'],
    legacyImpact: 'high',
    priority: 'critical'
  },
  {
    id: 'cr-002',
    title: 'OAuth 2.0 Migration',
    description: 'Migrate authentication from legacy LDAP to OAuth 2.0',
    systemId: 'sys-003',
    systemName: 'Authentication Service',
    requestedDate: '2024-12-15',
    estimatedDays: 60,
    status: 'in-progress',
    blockers: ['Downstream dependency mapping incomplete'],
    legacyImpact: 'high',
    priority: 'high'
  },
  {
    id: 'cr-003',
    title: 'API Rate Limiting',
    description: 'Implement rate limiting for payment gateway',
    systemId: 'sys-004',
    systemName: 'Payment Gateway',
    requestedDate: '2025-01-12',
    estimatedDays: 14,
    status: 'pending',
    blockers: [],
    legacyImpact: 'low',
    priority: 'medium'
  },
  {
    id: 'cr-004',
    title: 'Cloud Database Migration',
    description: 'Migrate customer data to cloud-native database',
    systemId: 'sys-002',
    systemName: 'Customer Data Platform',
    requestedDate: '2024-11-01',
    estimatedDays: 120,
    actualDays: 145,
    status: 'completed',
    blockers: [],
    legacyImpact: 'high',
    priority: 'critical'
  },
  {
    id: 'cr-005',
    title: 'Report Generation Optimization',
    description: 'Optimize batch report generation for faster execution',
    systemId: 'sys-005',
    systemName: 'Report Generator',
    requestedDate: '2025-01-08',
    estimatedDays: 30,
    status: 'pending',
    blockers: ['Requires Core Banking Engine change'],
    legacyImpact: 'medium',
    priority: 'low'
  },
  {
    id: 'cr-006',
    title: 'Push Notification Support',
    description: 'Add push notification channel to notification engine',
    systemId: 'sys-006',
    systemName: 'Notification Engine',
    requestedDate: '2024-12-20',
    estimatedDays: 21,
    status: 'in-progress',
    blockers: [],
    legacyImpact: 'low',
    priority: 'medium'
  }
]

export const bypassIncidents: BypassIncident[] = [
  {
    id: 'bp-001',
    type: 'shadow-system',
    description: 'Finance team using external spreadsheet for reconciliation due to slow batch processing',
    detectedDate: '2025-01-15',
    systemId: 'sys-008',
    systemName: 'Batch Processing',
    frequency: 45,
    riskLevel: 'critical',
    status: 'active',
    affectedUsers: 12,
    dataConsistencyRisk: true
  },
  {
    id: 'bp-002',
    type: 'script',
    description: 'Custom Python scripts extracting data directly from database bypassing API',
    detectedDate: '2025-01-10',
    systemId: 'sys-002',
    systemName: 'Customer Data Platform',
    frequency: 120,
    riskLevel: 'high',
    status: 'monitoring',
    affectedUsers: 5,
    dataConsistencyRisk: true
  },
  {
    id: 'bp-003',
    type: 'manual-workaround',
    description: 'Manual data entry due to authentication timeout issues',
    detectedDate: '2025-01-08',
    systemId: 'sys-003',
    systemName: 'Authentication Service',
    frequency: 30,
    riskLevel: 'medium',
    status: 'active',
    affectedUsers: 25,
    dataConsistencyRisk: false
  },
  {
    id: 'bp-004',
    type: 'external-tool',
    description: 'Third-party reporting tool used instead of Report Generator',
    detectedDate: '2024-12-20',
    systemId: 'sys-005',
    systemName: 'Report Generator',
    frequency: 85,
    riskLevel: 'high',
    status: 'active',
    affectedUsers: 18,
    dataConsistencyRisk: true
  },
  {
    id: 'bp-005',
    type: 'shadow-system',
    description: 'Duplicate customer records maintained in department-level Access database',
    detectedDate: '2024-11-15',
    systemId: 'sys-002',
    systemName: 'Customer Data Platform',
    frequency: 200,
    riskLevel: 'critical',
    status: 'active',
    affectedUsers: 8,
    dataConsistencyRisk: true
  },
  {
    id: 'bp-006',
    type: 'script',
    description: 'Automated email notifications via personal scripts due to notification delays',
    detectedDate: '2025-01-05',
    systemId: 'sys-006',
    systemName: 'Notification Engine',
    frequency: 60,
    riskLevel: 'medium',
    status: 'resolved',
    affectedUsers: 3,
    dataConsistencyRisk: false
  }
]

export const timelineMetrics: TimelineMetric[] = [
  { month: 'Aug', planned: 12, actual: 8, blocked: 4 },
  { month: 'Sep', planned: 15, actual: 10, blocked: 5 },
  { month: 'Oct', planned: 18, actual: 12, blocked: 6 },
  { month: 'Nov', planned: 14, actual: 11, blocked: 3 },
  { month: 'Dec', planned: 20, actual: 14, blocked: 6 },
  { month: 'Jan', planned: 16, actual: 9, blocked: 7 }
]

export const dependencyMetrics: DependencyMetric[] = [
  { name: 'Core Banking', couplingScore: 92, impactRadius: 85, changeVelocity: 15 },
  { name: 'Customer Data', couplingScore: 88, impactRadius: 78, changeVelocity: 25 },
  { name: 'Auth Service', couplingScore: 75, impactRadius: 90, changeVelocity: 35 },
  { name: 'Payment GW', couplingScore: 68, impactRadius: 45, changeVelocity: 55 },
  { name: 'Batch Proc', couplingScore: 72, impactRadius: 30, changeVelocity: 8 }
]

export const systemHealthMetrics: SystemHealthMetric[] = [
  { category: 'Integration Health', score: 62, trend: 'down' },
  { category: 'Change Velocity', score: 45, trend: 'stable' },
  { category: 'Technical Debt', score: 38, trend: 'down' },
  { category: 'Documentation', score: 55, trend: 'up' },
  { category: 'Test Coverage', score: 42, trend: 'stable' }
]

export const modernizationProjects: ModernizationProject[] = [
  {
    id: 'mod-001',
    name: 'Cloud Database Migration',
    description: 'Migrate Customer Data Platform to cloud-native PostgreSQL',
    legacySystemId: 'sys-002',
    legacySystemName: 'Customer Data Platform',
    modernSystemName: 'Cloud PostgreSQL Cluster',
    status: 'parallel',
    progress: 75,
    startDate: '2024-09-01',
    targetDate: '2025-03-15',
    complexity: 'critical',
    riskLevel: 'high',
    parallelRunning: true
  },
  {
    id: 'mod-002',
    name: 'Auth Service Upgrade',
    description: 'Replace LDAP authentication with OAuth 2.0 / OIDC',
    legacySystemId: 'sys-003',
    legacySystemName: 'Authentication Service',
    modernSystemName: 'OAuth 2.0 Gateway',
    status: 'migration',
    progress: 45,
    startDate: '2024-11-15',
    targetDate: '2025-04-30',
    complexity: 'high',
    riskLevel: 'medium',
    parallelRunning: true
  },
  {
    id: 'mod-003',
    name: 'Payment API Modernization',
    description: 'Rebuild Payment Gateway with modern REST/GraphQL APIs',
    legacySystemId: 'sys-004',
    legacySystemName: 'Payment Gateway',
    modernSystemName: 'Payment Service v2',
    status: 'planning',
    progress: 15,
    startDate: '2025-01-10',
    targetDate: '2025-08-01',
    complexity: 'high',
    riskLevel: 'high',
    parallelRunning: false
  },
  {
    id: 'mod-004',
    name: 'Report Generator Replacement',
    description: 'Replace batch reports with real-time analytics dashboard',
    legacySystemId: 'sys-005',
    legacySystemName: 'Report Generator',
    modernSystemName: 'Analytics Platform',
    status: 'migration',
    progress: 35,
    startDate: '2024-12-01',
    targetDate: '2025-06-30',
    complexity: 'medium',
    riskLevel: 'low',
    parallelRunning: false
  },
  {
    id: 'mod-005',
    name: 'Batch Processing Modernization',
    description: 'Convert batch jobs to event-driven microservices',
    legacySystemId: 'sys-008',
    legacySystemName: 'Batch Processing',
    modernSystemName: 'Event Processing Service',
    status: 'planning',
    progress: 10,
    startDate: '2025-02-01',
    targetDate: '2025-09-30',
    complexity: 'critical',
    riskLevel: 'high',
    parallelRunning: false
  }
]

export const complexityTrendData = [
  { month: 'Aug', legacy: 85, modern: 12, hybrid: 3 },
  { month: 'Sep', legacy: 82, modern: 14, hybrid: 4 },
  { month: 'Oct', legacy: 78, modern: 16, hybrid: 6 },
  { month: 'Nov', legacy: 72, modern: 20, hybrid: 8 },
  { month: 'Dec', legacy: 68, modern: 22, hybrid: 10 },
  { month: 'Jan', legacy: 62, modern: 26, hybrid: 12 }
]
