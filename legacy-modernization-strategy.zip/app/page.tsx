"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { Overview } from "@/components/dashboard/overview"
import { DependencyAnalysis } from "@/components/dashboard/dependency-analysis"
import { TimelineEvaluation } from "@/components/dashboard/timeline-evaluation"
import { BypassDetection } from "@/components/dashboard/bypass-detection"
import { cn } from "@/lib/utils"
import type { TabType } from "@/lib/types"

const tabConfig: Record<TabType, { title: string; subtitle: string }> = {
  overview: {
    title: "Overview",
    subtitle: "Legacy infrastructure modernization dashboard"
  },
  dependencies: {
    title: "Dependency Analysis",
    subtitle: "Scenario 1: Integration friction and coupling constraints"
  },
  timeline: {
    title: "Timeline Evaluation",
    subtitle: "Scenario 2: Change expectations and delivery communication"
  },
  bypass: {
    title: "Bypass Detection",
    subtitle: "Scenario 3: Shadow systems and workaround monitoring"
  }
}

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<TabType>("overview")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const handleNavigate = (tab: TabType) => {
    setActiveTab(tab)
  }

  const renderContent = () => {
    switch (activeTab) {
      case "overview":
        return <Overview onNavigate={handleNavigate} />
      case "dependencies":
        return <DependencyAnalysis />
      case "timeline":
        return <TimelineEvaluation />
      case "bypass":
        return <BypassDetection />
      default:
        return <Overview onNavigate={handleNavigate} />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        collapsed={sidebarCollapsed}
        onCollapsedChange={setSidebarCollapsed}
      />
      
      <div className={cn(
        "transition-all duration-300",
        sidebarCollapsed ? "ml-16" : "ml-64"
      )}>
        <Header 
          title={tabConfig[activeTab].title}
          subtitle={tabConfig[activeTab].subtitle}
        />
        
        <main className="p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  )
}
